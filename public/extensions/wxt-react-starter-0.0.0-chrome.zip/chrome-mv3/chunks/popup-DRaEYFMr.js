import{V as e,j as t,R as o}from"./tagsApi-BA95au7b.js";import{A as r}from"./App-CqAB6UcW.js";e.createRoot(document.getElementById("root")).render(t.jsx(o.StrictMode,{children:t.jsx(r,{})}));
