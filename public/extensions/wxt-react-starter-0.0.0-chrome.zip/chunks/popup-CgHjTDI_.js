import{Y as e,j as t,R as o}from"./tagsApi-5_T0ddsb.js";import{A as r}from"./App-C9syhXUc.js";e.createRoot(document.getElementById("root")).render(t.jsx(o.StrictMode,{children:t.jsx(r,{})}));
