import{Y as e,j as t,R as o}from"./tagsApi-Bi7nJbdv.js";import{A as r}from"./App-CUncnXmD.js";e.createRoot(document.getElementById("root")).render(t.jsx(o.StrictMode,{children:t.jsx(r,{})}));
